# Exercise 4.3 for "Numerical Methods for PDEs - Galerkin Methods", Summer Term 2022


To reproduce the meshes of different density just run the command on the terminal, once that u are in the folder of this proyect
Tho get the meshes that I used, run the following commands for the case of 3d
'''
gmsh cube.geo -3  -clscale 1  -o cube1.msh
gmsh cube.geo -3  -clscale 0.5  -o cube2.msh
gmsh cube.geo -3  -clscale 0.3  -o cube3.msh
gmsh cube.geo -3  -clscale 0.2  -o cube4.msh
'''
For 2d
'''
gmsh rectangulo.geo  -2   -clscale 1  -o reg1.msh
gmsh rectangulo.geo  -2   -clscale 0.5  -o reg2.msh
gmsh rectangulo.geo  -2   -clscale 0.3  -o reg3.msh
gmsh rectangulo.geo  -2   -clscale 0.2  -o reg4.msh
'''
For 1d
'''
 gmsh line.geo -1    -clscale 0.5  -o line1.msh
 gmsh line.geo -1    -clscale 0.4  -o line2.msh
 gmsh line.geo -1    -clscale 0.3  -o line3.msh
 gmsh line.geo -1    -clscale 0.2  -o line4.msh
''''
You can change the mesh size, if you want to add more meshes read the comment in the ex03() function in the code
You can reproduce the results by executing
```julia
include("exercise4_3.jl")
ex03()
```
Please see comments in the source file for further remarks.

The code was developed for Julia v1.7.2.
