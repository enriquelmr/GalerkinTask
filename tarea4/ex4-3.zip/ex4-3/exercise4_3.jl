using Gridap
using GridapGmsh
using Gridap.Io
using LinearAlgebra

using Pkg
Pkg.add("PrettyTables")
using PrettyTables: pretty_table, ft_printf

function Gridap.DiscreteModelFromFile(filename::AbstractString,::Val{:msh})
  model = GmshDiscreteModel(filename)
  model
end

#the function for the dirichlet boundary conditions as is defined in the excersice sheet
g(x)=sum(x)

 # here it goes the function of the right side of the poisson eq
#this is only a test function, we can chosse whichever and solve the problem
#because here we are trying to measure the run time
f(x) = norm(x)


function solve_poisson(mesh_file; order=1)
  # Load the mesh
  @info "Loading mesh file $mesh_file"
  model = GmshDiscreteModel(mesh_file)
  

  reffe = ReferenceFE(lagrangian, Float64, order)
  V0 = TestFESpace(model, reffe;conformity=:H1, dirichlet_tags=["wall"])
  U = TrialFESpace(V0, g)
    degree = 2 * order 
  Ω = Triangulation(model)
  dΩ = Measure(Ω, degree)

  
  a(u,v) = ∫( ∇(v) ⋅ ∇(u) ) * dΩ
  b(v) = ∫( v*f ) * dΩ
  op = AffineFEOperator(a, b, U, V0)

        A=get_matrix(op)
        bb=get_vector(op)
        A_dense=Matrix(A)
    #mesuring the run time
    time_sparse=  @elapsed begin cholesky(A)\bb end
    time_dense= @elapsed begin lu(A_dense)\bb end
  

#comment this \# if u  dont wanna get the solution file and plot it in paraview  
# for the puorposal of this asigment we can skip the visualization if we want
  #write the output as the entrance to identify each one
     uh = solve(op)
     filename = first(splitext(mesh_file)) * "_solution.vtu"
      writevtk(Ω, filename, cellfields=[ "uh" => uh])
###############################################################
  return [time_sparse, time_dense]
end

function ex03(; order =1)
    #here we r making a array with the names of the messhes that we have done in the terminal with gmsh command
    #if u wanna add more meshes densities jusnt increas ethe size of theese 3 vectors with the corresponding id
    file_name3=["cube1.msh","cube2.msh","cube3.msh","cube4.msh"]
    file_name2=["reg1.msh","reg2.msh","reg3.msh","reg4.msh"]
    file_name1=["line1.msh","line2.msh","line3.msh","line4.msh"]
    
    mesh_sizeCR=[1,0.5,0.3,0.2]
    mesh_sizeL=[0.5,0.4,0.3,0.2]
     
    # we create the variables that will storage our quantities 
    #this ones are for the diference of time
    dtc=zeros(size(file_name3,1))
    dtr=zeros(size(file_name2,1))
    dtl=zeros(size(file_name1,1))
    #this for the time solution for the sparse matrix method
    tsc=zeros(size(file_name3,1))
    tsr=zeros(size(file_name2,1))
    tsl=zeros(size(file_name1,1))
    #this for the time solution for the dense matrix method
    tmc=zeros(size(file_name3,1))
    tmr=zeros(size(file_name2,1))
    tml=zeros(size(file_name1,1))
    
    for i in 1:size(file_name3,1)
        #we call our function solve poisson and we send the mesh file as 
        tsc[i],tmc[i]=solve_poisson(file_name3[i])
        dtc[i]=abs(tsc[i]-tmc[i])
        
        
        #here we will solve for the case of 2dimentions calling the op operator renamed as rec
        #in every iteration we wouldnt save this value because we r only interested on the diference of time
        tsr[i],tmr[i]=solve_poisson(file_name2[i])
        dtr[i]=abs(tsr[i]-tmr[i])
        
        tsl[i],tml[i]=solve_poisson(file_name1[i])
        dtl[i]= abs(tsl[i]-tml[i])
    end
    
    #printing with pretty tables of N=3
      data = hcat(mesh_sizeCR, tsc, tmc,dtc)
      header = ["mesh_size","run-t Sparse sol(N=3)","run-t Dense sol(N=3)","diference time of sol"]
      kwargs = (; header, formatters=(ft_printf("%.2e", [1, 3]), ft_printf("%.2f", [2, 4])))
      pretty_table(data; kwargs...)
      pretty_table(data; kwargs..., backend=Val(:latex))
    #printing with pretty tables of N=2
     data = hcat( mesh_sizeCR,tsr, tmr,dtr)
      header = ["mesh_size", "run-t Sparse sol(N=2)","run-t Dense sol(N=2)","diference time of sol"]
      kwargs = (; header, formatters=(ft_printf("%.2e", [1, 3]), ft_printf("%.2f", [2, 4])))
      pretty_table(data; kwargs...)
      pretty_table(data; kwargs..., backend=Val(:latex))
    #printing with pretty tables of N=1
     data = hcat(mesh_sizeL, tsl, tml,dtl)
      header = ["mesh_size","run-t Sparse sol(N=1)","run-t Dense sol(N=1)","diference time of sol"]
      kwargs = (; header, formatters=(ft_printf("%.2e", [1, 3]), ft_printf("%.2f", [2, 4])))
      pretty_table(data; kwargs...)
      pretty_table(data; kwargs..., backend=Val(:latex))
    return nothing;
    
end




